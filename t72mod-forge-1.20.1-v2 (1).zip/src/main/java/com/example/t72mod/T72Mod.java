package com.example.t72mod;

import com.example.t72mod.entity.T72TankEntity;
import com.example.t72mod.entity.TankShellEntity;
import com.example.t72mod.entity.TankType;
import com.example.t72mod.inventory.TankInventoryMenu;
import com.example.t72mod.network.ModMessages;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.function.Supplier;

@Mod(T72Mod.MODID)
public class T72Mod {
    public static final String MODID = "t72mod";

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MODID);
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(ForgeRegistries.MENU_TYPES, MODID);
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    // 3 Tank Entity Types (central hull sized 1.75x1.40 so surrounding 0.85-high track/front/rear parts act as steps)
    public static final RegistryObject<EntityType<T72TankEntity>> T72_TANK = ENTITIES.register("t72_tank",
            () -> EntityType.Builder.<T72TankEntity>of(T72TankEntity::new, MobCategory.MISC)
                    .sized(1.75F, 1.40F)
                    .clientTrackingRange(12)
                    .updateInterval(1)
                    .fireImmune()
                    .build("t72_tank"));

    public static final RegistryObject<EntityType<T72TankEntity>> ABRAMS_TANK = ENTITIES.register("abrams_tank",
            () -> EntityType.Builder.<T72TankEntity>of(T72TankEntity::new, MobCategory.MISC)
                    .sized(1.85F, 1.42F)
                    .clientTrackingRange(12)
                    .updateInterval(1)
                    .fireImmune()
                    .build("abrams_tank"));

    public static final RegistryObject<EntityType<T72TankEntity>> LEOPARD2_TANK = ENTITIES.register("leopard2_tank",
            () -> EntityType.Builder.<T72TankEntity>of(T72TankEntity::new, MobCategory.MISC)
                    .sized(1.80F, 1.40F)
                    .clientTrackingRange(12)
                    .updateInterval(1)
                    .fireImmune()
                    .build("leopard2_tank"));

    public static final RegistryObject<EntityType<TankShellEntity>> TANK_SHELL = ENTITIES.register("tank_shell",
            () -> EntityType.Builder.<TankShellEntity>of(TankShellEntity::new, MobCategory.MISC)
                    .sized(0.35F, 0.35F)
                    .clientTrackingRange(16)
                    .updateInterval(1)
                    .build("tank_shell"));

    public static final RegistryObject<MenuType<TankInventoryMenu>> TANK_MENU = MENUS.register("tank_inventory_menu",
            () -> IForgeMenuType.create(TankInventoryMenu::new));

    // Helper for tank spawner items
    private static Item createTankSpawnerItem(Supplier<EntityType<T72TankEntity>> entityTypeSupplier, TankType tankType) {
        return new Item(new Item.Properties().stacksTo(1)) {
            @Override
            public InteractionResult useOn(UseOnContext ctx) {
                Level level = ctx.getLevel();
                if (!level.isClientSide) {
                    BlockPos pos = ctx.getClickedPos().relative(ctx.getClickedFace());
                    T72TankEntity tank = entityTypeSupplier.get().create(level);
                    if (tank != null) {
                        tank.setTankType(tankType);
                        tank.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, ctx.getRotation(), 0.0F);
                        tank.setTurretYaw(ctx.getRotation());
                        tank.initStarterSupplies();
                        level.addFreshEntity(tank);
                        if (ctx.getPlayer() != null && !ctx.getPlayer().getAbilities().instabuild) {
                            ctx.getItemInHand().shrink(1);
                        }
                    }
                }
                return InteractionResult.sidedSuccess(level.isClientSide);
            }
        };
    }

    // Tank Spawner Items
    public static final RegistryObject<Item> T72_SPAWN_ITEM = ITEMS.register("t72_spawner",
            () -> createTankSpawnerItem(T72_TANK, TankType.T72B));
    public static final RegistryObject<Item> ABRAMS_SPAWN_ITEM = ITEMS.register("abrams_spawner",
            () -> createTankSpawnerItem(ABRAMS_TANK, TankType.ABRAMS));
    public static final RegistryObject<Item> LEOPARD2_SPAWN_ITEM = ITEMS.register("leopard2_spawner",
            () -> createTankSpawnerItem(LEOPARD2_TANK, TankType.LEOPARD2));

    // Ammo, Fuel, Repair & AI Crew Items
    public static final RegistryObject<Item> SHELL_125MM = ITEMS.register("shell_125mm",
            () -> new Item(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> SHELL_120MM = ITEMS.register("shell_120mm",
            () -> new Item(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> MG_AMMO_BOX = ITEMS.register("mg_ammo_box",
            () -> new Item(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> FUEL_CANISTER = ITEMS.register("fuel_canister",
            () -> new Item(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> REPAIR_KIT = ITEMS.register("repair_kit",
            () -> new Item(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> AI_CREW_CHIP = ITEMS.register("ai_crew_chip",
            () -> new Item(new Item.Properties().stacksTo(16)));

    public static final RegistryObject<CreativeModeTab> TANK_TAB = TABS.register("tank_tab",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.t72mod"))
                    .icon(() -> new ItemStack(T72_SPAWN_ITEM.get()))
                    .displayItems((params, output) -> {
                        output.accept(T72_SPAWN_ITEM.get());
                        output.accept(ABRAMS_SPAWN_ITEM.get());
                        output.accept(LEOPARD2_SPAWN_ITEM.get());
                        output.accept(SHELL_125MM.get());
                        output.accept(SHELL_120MM.get());
                        output.accept(MG_AMMO_BOX.get());
                        output.accept(FUEL_CANISTER.get());
                        output.accept(REPAIR_KIT.get());
                        output.accept(AI_CREW_CHIP.get());
                    })
                    .build());

    public T72Mod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        ENTITIES.register(modEventBus);
        ITEMS.register(modEventBus);
        MENUS.register(modEventBus);
        TABS.register(modEventBus);

        modEventBus.addListener(this::commonSetup);
        modEventBus.addListener(this::registerAttributes);
        MinecraftForge.EVENT_BUS.register(this);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(ModMessages::register);
    }

    private void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(T72_TANK.get(), T72TankEntity.createAttributes().build());
        event.put(ABRAMS_TANK.get(), T72TankEntity.createAbramsAttributes().build());
        event.put(LEOPARD2_TANK.get(), T72TankEntity.createLeopard2Attributes().build());
    }

    // Complete crew invulnerability while inside an intact tank; redirect heavy external hits to the tank itself
    @SubscribeEvent
    public void onLivingAttack(LivingAttackEvent event) {
        if (event.getEntity() instanceof Player player && player.getVehicle() instanceof T72TankEntity tank && tank.isAlive()) {
            if (!event.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
                event.setCanceled(true);
                // If a Warden or heavy enemy attacks the player directly (e.g. Sonic Boom), redirect damage to the tank
                if (!player.level().isClientSide && (event.getSource().getEntity() instanceof Warden || event.getAmount() >= 14.0F)) {
                    tank.hurt(event.getSource(), event.getAmount());
                }
            }
        }
    }

    @SubscribeEvent
    public void onLivingHurt(LivingHurtEvent event) {
        if (event.getEntity() instanceof Player player && player.getVehicle() instanceof T72TankEntity tank && tank.isAlive()) {
            if (!event.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
                event.setCanceled(true);
            }
        }
    }
}
