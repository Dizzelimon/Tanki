package com.example.t72mod.entity;

public enum TankType {
    T72B(
            "t72_tank",
            "Т-72Б",
            300.0D,
            24.0D,
            0.25F,
            0.38F,
            2.2F,
            8.5F,
            -16.0F,
            6.0F,
            80,
            4.8F,
            0.012F,
            115.0F,
            5.5F,
            0.28D,
            1.0F,
            "125-мм 2А46 (АЗ)"
    ),
    ABRAMS(
            "abrams_tank",
            "M1A2 Abrams",
            380.0D,
            28.0D,
            0.27F,
            0.65F,
            2.5F,
            12.5F,
            -20.0F,
            10.0F,
            65,
            5.8F,
            0.008F,
            135.0F,
            4.2F,
            0.22D,
            1.45F,
            "120-мм M256"
    ),
    LEOPARD2(
            "leopard2_tank",
            "Leopard 2A6",
            320.0D,
            25.0D,
            0.31F,
            0.70F,
            2.8F,
            13.5F,
            -20.0F,
            9.0F,
            60,
            6.5F,
            0.005F,
            150.0F,
            4.0F,
            0.20D,
            0.95F,
            "120-мм Rh-120 L/55"
    );

    public final String id;
    public final String displayName;
    public final double maxHealth;
    public final double armor;
    public final float driveSpeed;
    public final float reverseFactor;
    public final float hullTurnSpeed;
    public final float turretTurnSpeed;
    public final float minBarrelPitch; // negative = looking UP
    public final float maxBarrelPitch; // positive = looking DOWN
    public final int reloadTicks;
    public final float shellSpeed;
    public final float shellGravity;
    public final float shellDirectDamage;
    public final float shellExplosionRadius;
    public final double zoomFovMultiplier;
    public final float fuelConsumptionMult;
    public final String cannonTitle;

    TankType(String id, String displayName, double maxHealth, double armor,
             float driveSpeed, float reverseFactor, float hullTurnSpeed, float turretTurnSpeed,
             float minBarrelPitch, float maxBarrelPitch, int reloadTicks,
             float shellSpeed, float shellGravity, float shellDirectDamage, float shellExplosionRadius,
             double zoomFovMultiplier, float fuelConsumptionMult, String cannonTitle) {
        this.id = id;
        this.displayName = displayName;
        this.maxHealth = maxHealth;
        this.armor = armor;
        this.driveSpeed = driveSpeed;
        this.reverseFactor = reverseFactor;
        this.hullTurnSpeed = hullTurnSpeed;
        this.turretTurnSpeed = turretTurnSpeed;
        this.minBarrelPitch = minBarrelPitch;
        this.maxBarrelPitch = maxBarrelPitch;
        this.reloadTicks = reloadTicks;
        this.shellSpeed = shellSpeed;
        this.shellGravity = shellGravity;
        this.shellDirectDamage = shellDirectDamage;
        this.shellExplosionRadius = shellExplosionRadius;
        this.zoomFovMultiplier = zoomFovMultiplier;
        this.fuelConsumptionMult = fuelConsumptionMult;
        this.cannonTitle = cannonTitle;
    }

    public static TankType byOrdinal(int ord) {
        TankType[] vals = values();
        if (ord < 0 || ord >= vals.length) return T72B;
        return vals[ord];
    }
}
