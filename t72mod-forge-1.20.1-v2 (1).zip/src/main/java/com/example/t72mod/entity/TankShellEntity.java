package com.example.t72mod.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableProjectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.List;

public class TankShellEntity extends ThrowableProjectile {
    private static final EntityDataAccessor<Float> DATA_GRAVITY =
            SynchedEntityData.defineId(TankShellEntity.class, EntityDataSerializers.FLOAT);

    private float directDamage = 115.0F;
    private float explosionRadius = 5.5F;
    private int shooterTankId = -1;
    private boolean hitTankDirectly = false;

    public TankShellEntity(EntityType<? extends ThrowableProjectile> type, Level level) {
        super(type, level);
    }

    public void configureShell(int shooterTankId, float directDamage, float explosionRadius, float gravity) {
        this.shooterTankId = shooterTankId;
        this.directDamage = directDamage;
        this.explosionRadius = explosionRadius;
        this.entityData.set(DATA_GRAVITY, gravity);
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(DATA_GRAVITY, 0.010F);
    }

    @Override
    protected float getGravity() {
        return this.entityData.get(DATA_GRAVITY);
    }

    @Override
    protected boolean canHitEntity(Entity target) {
        if (target.getId() == this.shooterTankId) return false;
        if (target instanceof TankPartEntity part && part.getParent().getId() == this.shooterTankId) return false;
        if (this.getOwner() != null && target.isPassengerOfSameVehicle(this.getOwner())) return false;
        return super.canHitEntity(target) || target instanceof TankPartEntity;
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            Vec3 pos = this.position();
            this.level().addParticle(ParticleTypes.SMOKE, pos.x, pos.y, pos.z, 0, 0, 0);
            this.level().addParticle(ParticleTypes.FLAME, pos.x, pos.y, pos.z, 0, 0, 0);
        } else {
            // Check direct intersection with TankPartEntity sub-hitboxes along flight path
            Vec3 start = this.position();
            Vec3 end = start.add(this.getDeltaMovement());
            AABB pathBox = this.getBoundingBox().expandTowards(this.getDeltaMovement()).inflate(0.35D);
            List<T72TankEntity> nearbyTanks = this.level().getEntitiesOfClass(T72TankEntity.class, pathBox.inflate(2.5D),
                    t -> t.isAlive() && t.getId() != this.shooterTankId);
            for (T72TankEntity tank : nearbyTanks) {
                for (TankPartEntity part : tank.getTankParts()) {
                    if (part.getBoundingBox().inflate(0.25D).clip(start, end).isPresent()
                            || part.getBoundingBox().intersects(this.getBoundingBox())) {
                        this.onHitEntity(new EntityHitResult(part, start));
                        this.detonateAt(start);
                        return;
                    }
                }
            }
        }
        if (this.tickCount > 200) {
            this.discard();
        }
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        if (this.level().isClientSide) return;

        Entity target = result.getEntity();
        Vec3 hitPos = result.getLocation();

        if (target instanceof TankPartEntity part) {
            T72TankEntity parent = part.getParent();
            if (parent.getId() != this.shooterTankId) {
                this.hitTankDirectly = true;
                parent.onDirectShellHit(part.moduleType, hitPos, this, this.directDamage);
            }
        } else if (target instanceof T72TankEntity tank) {
            if (tank.getId() != this.shooterTankId) {
                this.hitTankDirectly = true;
                int module = tank.resolveModuleAtPosition(hitPos);
                tank.onDirectShellHit(module, hitPos, this, this.directDamage);
            }
        } else if (target instanceof LivingEntity living) {
            living.invulnerableTime = 0;
            living.hurt(this.damageSources().thrown(this, this.getOwner()), this.directDamage);
        }
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (!this.level().isClientSide) {
            this.detonateAt(result.getLocation());
        }
    }

    private void detonateAt(Vec3 hit) {
        if (this.isRemoved()) return;

        // If shell hit near a tank without direct hit, apply splash damage to nearest module (usually tracks)
        if (!this.hitTankDirectly) {
            List<T72TankEntity> splashTanks = this.level().getEntitiesOfClass(
                    T72TankEntity.class,
                    new AABB(hit, hit).inflate(4.2D),
                    t -> t.isAlive() && t.getId() != this.shooterTankId
            );
            for (T72TankEntity tank : splashTanks) {
                double dist = Math.sqrt(tank.distanceToSqr(hit));
                if (dist < 4.5D) {
                    float factor = (float) Math.max(0.25D, 1.0D - (dist / 4.8D));
                    int module = tank.resolveModuleAtPosition(hit);
                    tank.onDirectShellHit(module, hit, this, this.directDamage * 0.65F * factor);
                }
            }
        }

        this.level().explode(
                this,
                hit.x, hit.y, hit.z,
                this.explosionRadius,
                Level.ExplosionInteraction.TNT
        );

        this.discard();
    }
}
