package com.example.t72mod.entity;

import com.example.t72mod.T72Mod;
import com.example.t72mod.inventory.TankInventoryMenu;
import com.example.t72mod.network.ModMessages;
import com.example.t72mod.network.TankAimInputPacket;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Ravager;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.entity.PartEntity;
import net.minecraftforge.network.NetworkHooks;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class T72TankEntity extends PathfinderMob implements MenuProvider {
    private static final EntityDataAccessor<Float> DATA_TURRET_YAW =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> DATA_BARREL_PITCH =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Boolean> DATA_HATCH_OPEN =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> DATA_RELOAD_TICKS =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_RECOIL_TICKS =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_SMOKE_COOLDOWN =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.INT);

    // New synched fields: TankType, Fuel, MG Ammo, Shell Count, Module Healths, AI Mode
    private static final EntityDataAccessor<Integer> DATA_TANK_TYPE =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_FUEL =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_MG_AMMO =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_SHELL_COUNT =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_TURRET_HEALTH =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_TRACKS_HEALTH =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_ENGINE_HEALTH =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> DATA_ENEMY_AI =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.BOOLEAN);

    public static final int MAX_FUEL = 1000;
    public static final int MAX_MG_AMMO = 1000;
    public static final int MAX_MODULE_HEALTH = 100;

    public float prevTurretYaw;
    public float prevBarrelPitch;
    public float wheelRotation;

    // Client-local smooth aim state to eliminate server packet rubber-banding
    private float clientDriverTurretYaw = 0.0F;
    private float clientDriverBarrelPitch = 0.0F;
    private boolean clientDriverAimInitialized = false;

    private int fuelBurnTicker = 0;
    private boolean starterLoadoutInitialized = false;

    // 9-slot tank inventory (0..3: Cannon shells, 4..5: MG ammo boxes, 6..7: Fuel, 8: Repair kit)
    private final SimpleContainer tankInventory = new SimpleContainer(TankInventoryMenu.TANK_SLOT_COUNT);

    // 5 Sub-Hitboxes (Tracks, Front Glacis, Rear Engine Deck, Turret) for stepping onto the tank & modular hits
    private final TankPartEntity leftTrackPart;
    private final TankPartEntity rightTrackPart;
    private final TankPartEntity frontHullPart;
    private final TankPartEntity rearHullPart;
    private final TankPartEntity turretPart;
    private final TankPartEntity[] subParts;

    public T72TankEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setMaxUpStep(1.5F);
        this.blocksBuilding = true;

        if (type == T72Mod.ABRAMS_TANK.get()) {
            this.setTankType(TankType.ABRAMS);
        } else if (type == T72Mod.LEOPARD2_TANK.get()) {
            this.setTankType(TankType.LEOPARD2);
        } else {
            this.setTankType(TankType.T72B);
        }

        // Lower outer hitboxes (0.85 blocks high) so the player can easily jump onto tracks, front, or back
        this.leftTrackPart = new TankPartEntity(this, "left_track", TankPartEntity.MODULE_TRACKS, 1.05F, 0.85F);
        this.rightTrackPart = new TankPartEntity(this, "right_track", TankPartEntity.MODULE_TRACKS, 1.05F, 0.85F);
        this.frontHullPart = new TankPartEntity(this, "front_hull", TankPartEntity.MODULE_HULL_FRONT, 1.85F, 0.85F);
        this.rearHullPart = new TankPartEntity(this, "rear_hull", TankPartEntity.MODULE_ENGINE, 1.85F, 0.88F);
        this.turretPart = new TankPartEntity(this, "turret", TankPartEntity.MODULE_TURRET, 1.65F, 0.78F);
        this.subParts = new TankPartEntity[]{
                this.leftTrackPart, this.rightTrackPart, this.frontHullPart, this.rearHullPart, this.turretPart
        };
    }

    @Override
    public void setId(int id) {
        super.setId(id);
        if (this.subParts != null) {
            for (int i = 0; i < this.subParts.length; i++) {
                this.subParts[i].setId(id + i + 1);
            }
        }
    }

    @Override
    public boolean isMultipartEntity() {
        return true;
    }

    @Override
    public PartEntity<?>[] getParts() {
        return this.subParts;
    }

    public TankPartEntity[] getTankParts() {
        return this.subParts;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 300.0D)
                .add(Attributes.ARMOR, 24.0D)
                .add(Attributes.ARMOR_TOUGHNESS, 16.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.35D);
    }

    public static AttributeSupplier.Builder createAbramsAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 380.0D)
                .add(Attributes.ARMOR, 28.0D)
                .add(Attributes.ARMOR_TOUGHNESS, 18.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.36D);
    }

    public static AttributeSupplier.Builder createLeopard2Attributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 320.0D)
                .add(Attributes.ARMOR, 25.0D)
                .add(Attributes.ARMOR_TOUGHNESS, 17.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.38D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_TURRET_YAW, 0.0F);
        this.entityData.define(DATA_BARREL_PITCH, 0.0F);
        this.entityData.define(DATA_HATCH_OPEN, true);
        this.entityData.define(DATA_RELOAD_TICKS, 0);
        this.entityData.define(DATA_RECOIL_TICKS, 0);
        this.entityData.define(DATA_SMOKE_COOLDOWN, 0);
        this.entityData.define(DATA_TANK_TYPE, 0);
        this.entityData.define(DATA_FUEL, 500);
        this.entityData.define(DATA_MG_AMMO, 250);
        this.entityData.define(DATA_SHELL_COUNT, 0);
        this.entityData.define(DATA_TURRET_HEALTH, MAX_MODULE_HEALTH);
        this.entityData.define(DATA_TRACKS_HEALTH, MAX_MODULE_HEALTH);
        this.entityData.define(DATA_ENGINE_HEALTH, MAX_MODULE_HEALTH);
        this.entityData.define(DATA_ENEMY_AI, false);
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        // Prevent server synched data packets from snapping the local driver's smooth turret aim
        if (this.level().isClientSide && this.getControllingPassenger() instanceof Player p && p.isLocalPlayer()) {
            if (!this.isTurretBroken()) {
                if (DATA_TURRET_YAW.equals(key) && this.clientDriverAimInitialized) {
                    this.entityData.set(DATA_TURRET_YAW, this.clientDriverTurretYaw);
                } else if (DATA_BARREL_PITCH.equals(key) && this.clientDriverAimInitialized) {
                    this.entityData.set(DATA_BARREL_PITCH, this.clientDriverBarrelPitch);
                }
            }
        }
    }

    public void initStarterSupplies() {
        if (this.starterLoadoutInitialized) return;
        this.starterLoadoutInitialized = true;
        TankType type = this.getTankType();
        if (type == TankType.T72B) {
            this.tankInventory.setItem(0, new ItemStack(T72Mod.SHELL_125MM.get(), 8));
        } else {
            this.tankInventory.setItem(0, new ItemStack(T72Mod.SHELL_120MM.get(), 8));
        }
        this.tankInventory.setItem(4, new ItemStack(T72Mod.MG_AMMO_BOX.get(), 2));
        this.tankInventory.setItem(6, new ItemStack(T72Mod.FUEL_CANISTER.get(), 1));
        this.tankInventory.setItem(8, new ItemStack(T72Mod.REPAIR_KIT.get(), 2));
        this.updateShellCountData();
    }

    @Override
    protected void registerGoals() {
    }

    @Override
    protected float tickHeadTurn(float bodyRot, float animStep) {
        // Keep hull rotation strictly independent from turret rotation so LivingEntity never twists the body
        this.yBodyRot = this.getYRot();
        this.yBodyRotO = this.yRotO;
        return 0.0F;
    }

    @Override
    public boolean canBeCollidedWith() {
        return this.isAlive();
    }

    @Override
    public boolean canCollideWith(Entity other) {
        if (other instanceof TankPartEntity part && part.getParent() == this) return false;
        return (other.canBeCollidedWith() || other.isPushable()) && !this.isPassengerOfSameVehicle(other);
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    public SimpleContainer getTankInventory() {
        return this.tankInventory;
    }

    public static boolean isMainShellItem(ItemStack stack) {
        return stack.is(T72Mod.SHELL_125MM.get()) || stack.is(T72Mod.SHELL_120MM.get());
    }

    public static int getFuelValue(ItemStack stack) {
        if (stack.is(T72Mod.FUEL_CANISTER.get())) return 500;
        if (stack.is(Items.COAL_BLOCK)) return 400;
        if (stack.is(Items.LAVA_BUCKET)) return 800;
        if (stack.is(Items.COAL) || stack.is(Items.CHARCOAL)) return 60;
        return 0;
    }

    public static boolean isRepairItem(ItemStack stack) {
        return stack.is(T72Mod.REPAIR_KIT.get()) || stack.is(Items.IRON_BLOCK) || stack.is(Items.IRON_INGOT);
    }

    public InteractionResult interactFromPart(TankPartEntity part, Player player, InteractionHand hand) {
        return this.handleTankInteraction(player, hand, part.moduleType == TankPartEntity.MODULE_TURRET);
    }

    @Override
    public InteractionResult interactAt(Player player, Vec3 clickVec, InteractionHand hand) {
        boolean clickedUpperArea = clickVec.y >= 1.15D;
        return this.handleTankInteraction(player, hand, clickedUpperArea);
    }

    private InteractionResult handleTankInteraction(Player player, InteractionHand hand, boolean clickedUpperArea) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;

        ItemStack stack = player.getItemInHand(hand);

        // 1. Toggle Enemy AI Crew mode if clicked with AI Crew Chip
        if (stack.is(T72Mod.AI_CREW_CHIP.get())) {
            if (!this.level().isClientSide) {
                boolean nextAi = !this.isEnemyAI();
                this.setEnemyAI(nextAi);
                this.setHatchOpen(!nextAi);
                if (nextAi && !this.starterLoadoutInitialized) {
                    this.initStarterSupplies();
                }
                this.level().playSound(null, this.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 1.0F, nextAi ? 0.7F : 1.3F);
                player.displayClientMessage(Component.literal(nextAi
                                ? "⚠ Активирован вражеский ИИ-экипаж (" + this.getTankType().displayName + ")! Танк будет атаковать цели."
                                : "ИИ-экипаж отключён. Танк переведён в ручной режим.")
                        .withStyle(nextAi ? ChatFormatting.RED : ChatFormatting.GREEN), true);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }

        // 2. Quick external repair with Repair Kit, Iron Block, or Iron Ingot
        if (isRepairItem(stack) && (this.getHealth() < this.getMaxHealth() || this.hasBrokenModules())) {
            if (!this.level().isClientSide) {
                this.applyRepairItem(stack, player);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }

        // 3. Quick external refuel with Fuel Canister or Coal
        int fuelAdd = getFuelValue(stack);
        if (fuelAdd > 0 && this.getFuel() < MAX_FUEL) {
            if (!this.level().isClientSide) {
                this.setFuel(Math.min(MAX_FUEL, this.getFuel() + fuelAdd));
                if (!player.getAbilities().instabuild) stack.shrink(1);
                this.level().playSound(null, this.blockPosition(), SoundEvents.BUCKET_FILL, SoundSource.PLAYERS, 1.0F, 1.0F);
                player.displayClientMessage(Component.literal("Топливный бак заправлен: " + this.getFuel() + "/" + MAX_FUEL)
                        .withStyle(ChatFormatting.GOLD), true);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }

        // 4. Quick external ammo load if holding shells or MG ammo box
        if (isMainShellItem(stack) || stack.is(T72Mod.MG_AMMO_BOX.get())) {
            if (!this.level().isClientSide && player instanceof ServerPlayer sp) {
                this.openTankInventory(sp);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }

        double playerHeightAboveGround = player.getY() - this.getY();
        double horizontalDist = Math.hypot(player.getX() - this.getX(), player.getZ() - this.getZ());
        boolean isOnTankOrStep = playerHeightAboveGround >= 0.65D && horizontalDist <= 3.0D;

        if (player.isShiftKeyDown()) {
            // If standing on ground and Shift+Right-Clicking hull, open Tank Inventory unless clicking upper hatch
            if (!isOnTankOrStep && !clickedUpperArea) {
                if (!this.level().isClientSide && player instanceof ServerPlayer sp) {
                    this.openTankInventory(sp);
                }
                return InteractionResult.sidedSuccess(this.level().isClientSide);
            }

            // Toggle Hatch
            if (!this.level().isClientSide) {
                boolean nextState = !this.isHatchOpen();
                this.setHatchOpen(nextState);
                this.level().playSound(null, this.blockPosition(),
                        nextState ? SoundEvents.IRON_TRAPDOOR_OPEN : SoundEvents.IRON_TRAPDOOR_CLOSE,
                        SoundSource.BLOCKS, 1.0F, 0.75F);
                player.displayClientMessage(Component.literal(nextState ? "Люк башни открыт" : "Люк башни задраен")
                        .withStyle(ChatFormatting.YELLOW), true);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }

        if (this.isEnemyAI()) {
            if (!this.level().isClientSide) {
                player.displayClientMessage(Component.literal("Внутри вражеский ИИ-экипаж! Отключите его чипом ИИ-экипажа.")
                        .withStyle(ChatFormatting.RED), true);
            }
            return InteractionResult.FAIL;
        }

        if (!this.isVehicle()) {
            if (!isOnTankOrStep && !clickedUpperArea) {
                if (!this.level().isClientSide) {
                    player.displayClientMessage(Component.literal("Запрыгните на гусеницу, нос или корму танка, чтобы забраться в люк! (Shift+ПКМ с земли — боеукладка)")
                            .withStyle(ChatFormatting.GOLD), true);
                }
                return InteractionResult.FAIL;
            }

            if (!this.isHatchOpen()) {
                if (!this.level().isClientSide) {
                    player.displayClientMessage(Component.literal("Люк башни закрыт! Нажмите Shift + ПКМ по башне, чтобы открыть его.")
                            .withStyle(ChatFormatting.RED), true);
                }
                return InteractionResult.FAIL;
            }

            if (!this.level().isClientSide) {
                if (!this.starterLoadoutInitialized) {
                    this.initStarterSupplies();
                }
                player.startRiding(this);
                this.setHatchOpen(false);
                this.level().playSound(null, this.blockPosition(), SoundEvents.IRON_TRAPDOOR_CLOSE, SoundSource.BLOCKS, 1.0F, 0.7F);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }

        return InteractionResult.PASS;
    }

    public void openTankInventory(ServerPlayer player) {
        if (!this.starterLoadoutInitialized) {
            this.initStarterSupplies();
        }
        NetworkHooks.openScreen(player, this, buf -> buf.writeInt(this.getId()));
    }

    @Override
    public Component getDisplayName() {
        return Component.literal("Укладка: " + this.getTankType().displayName);
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory playerInv, Player player) {
        return new TankInventoryMenu(containerId, playerInv, this.tankInventory, this);
    }

    public boolean hasBrokenModules() {
        return this.getTurretHealth() < MAX_MODULE_HEALTH
                || this.getTracksHealth() < MAX_MODULE_HEALTH
                || this.getEngineHealth() < MAX_MODULE_HEALTH;
    }

    public void performFieldRepair(Player player) {
        if (this.level().isClientSide) return;
        if (this.getHealth() >= this.getMaxHealth() && !this.hasBrokenModules()) {
            player.displayClientMessage(Component.literal("Все узлы и броня танка исправны!")
                    .withStyle(ChatFormatting.GREEN), true);
            return;
        }

        // Check slot 8 in tank inventory first, then player's inventory
        ItemStack repairStack = this.tankInventory.getItem(8);
        if (repairStack.isEmpty() || !isRepairItem(repairStack)) {
            repairStack = ItemStack.EMPTY;
            for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
                ItemStack s = player.getInventory().getItem(i);
                if (isRepairItem(s)) {
                    repairStack = s;
                    break;
                }
            }
        }

        if (repairStack.isEmpty() && !player.getAbilities().instabuild) {
            player.displayClientMessage(Component.literal("Нет ремкомплекта (ЗИП) или железа в слоте ремонта / инвентаре!")
                    .withStyle(ChatFormatting.RED), true);
            this.level().playSound(null, this.blockPosition(), SoundEvents.DISPENSER_FAIL, SoundSource.PLAYERS, 1.0F, 0.8F);
            return;
        }

        if (player.getAbilities().instabuild && repairStack.isEmpty()) {
            this.setTurretHealth(MAX_MODULE_HEALTH);
            this.setTracksHealth(MAX_MODULE_HEALTH);
            this.setEngineHealth(MAX_MODULE_HEALTH);
            this.heal(120.0F);
            this.level().playSound(null, this.blockPosition(), SoundEvents.ANVIL_USE, SoundSource.PLAYERS, 1.0F, 1.1F);
            player.displayClientMessage(Component.literal("Все модули (башня, гусеницы, двигатель) и броня отремонтированы!")
                    .withStyle(ChatFormatting.GREEN), true);
            return;
        }

        this.applyRepairItem(repairStack, player);
    }

    private void applyRepairItem(ItemStack stack, Player player) {
        boolean isFullKit = stack.is(T72Mod.REPAIR_KIT.get());
        boolean isBlock = stack.is(Items.IRON_BLOCK);

        float healAmount = isFullKit ? 110.0F : (isBlock ? 55.0F : 15.0F);
        int moduleRestore = isFullKit ? 100 : (isBlock ? 70 : 35);

        this.heal(healAmount);
        this.setTurretHealth(Math.min(MAX_MODULE_HEALTH, this.getTurretHealth() + moduleRestore));
        this.setTracksHealth(Math.min(MAX_MODULE_HEALTH, this.getTracksHealth() + moduleRestore));
        this.setEngineHealth(Math.min(MAX_MODULE_HEALTH, this.getEngineHealth() + moduleRestore));

        if (!player.getAbilities().instabuild) {
            stack.shrink(1);
        }

        this.level().playSound(null, this.blockPosition(), SoundEvents.ANVIL_USE, SoundSource.PLAYERS, 1.0F, 1.15F);
        player.displayClientMessage(Component.literal(String.format(
                        "Ремонт выполнен! Броня: %d/%d | Башня: %d%% | Гусеницы: %d%% | Двигатель: %d%%",
                        (int) this.getHealth(), (int) this.getMaxHealth(),
                        this.getTurretHealth(), this.getTracksHealth(), this.getEngineHealth()))
                .withStyle(ChatFormatting.GREEN), true);
    }

    @Override
    protected void removePassenger(Entity passenger) {
        super.removePassenger(passenger);
        if (!this.level().isClientSide && passenger instanceof Player) {
            this.setHatchOpen(true);
            this.level().playSound(null, this.blockPosition(), SoundEvents.IRON_TRAPDOOR_OPEN, SoundSource.BLOCKS, 1.0F, 0.75F);
            passenger.setPos(this.getX(), this.getY() + 1.65D, this.getZ());
        }
        if (this.level().isClientSide) {
            this.clientDriverAimInitialized = false;
        }
    }

    @Override
    public Vec3 getDismountLocationForPassenger(LivingEntity passenger) {
        return new Vec3(this.getX(), this.getY() + 1.65D, this.getZ());
    }

    @Override
    public double getPassengersRidingOffset() {
        return 0.85D;
    }

    @Nullable
    @Override
    public LivingEntity getControllingPassenger() {
        return this.getFirstPassenger() instanceof LivingEntity living ? living : null;
    }

    public void applyClientTurretAim(float clientYaw, float clientPitch) {
        if (this.isTurretBroken()) return;
        TankType type = this.getTankType();
        float clampedPitch = Mth.clamp(clientPitch, type.minBarrelPitch, type.maxBarrelPitch);
        this.setTurretYaw(Mth.wrapDegrees(clientYaw));
        this.setBarrelPitch(clampedPitch);
    }

    @Override
    public void tick() {
        this.prevTurretYaw = this.getTurretYaw();
        this.prevBarrelPitch = this.getBarrelPitch();

        super.tick();

        // Keep body rotation strictly locked to hull YRot so vanilla LivingEntity never twists the hull
        this.yBodyRot = this.getYRot();
        this.yBodyRotO = this.yRotO;
        this.yHeadRot = this.getYRot();
        this.yHeadRotO = this.yRotO;

        this.updateSubPartPositions();
        this.assistNearbyClimbingPlayers();

        if (this.getReloadTicks() > 0) this.setReloadTicks(this.getReloadTicks() - 1);
        if (this.getRecoilTicks() > 0) this.setRecoilTicks(this.getRecoilTicks() - 1);
        if (this.getSmokeCooldown() > 0) this.setSmokeCooldown(this.getSmokeCooldown() - 1);

        if (!this.level().isClientSide) {
            if (!this.starterLoadoutInitialized) {
                this.initStarterSupplies();
            }
            if (this.getReloadTicks() == 1) {
                this.level().playSound(null, this.blockPosition(), SoundEvents.IRON_DOOR_CLOSE, SoundSource.PLAYERS, 1.2F, 1.4F);
            }
            this.tickSupplyAutoLoad();
        }

        // Emit damage smoke/sparks if modules are broken
        if (this.level().isClientSide) {
            if (this.isEngineBroken() && this.tickCount % 2 == 0) {
                double rad = Math.toRadians(this.getYRot());
                double backX = this.getX() + Math.sin(rad) * 1.6D;
                double backZ = this.getZ() - Math.cos(rad) * 1.6D;
                this.level().addParticle(ParticleTypes.LARGE_SMOKE, backX, this.getY() + 1.1D, backZ, 0.0D, 0.06D, 0.0D);
                this.level().addParticle(ParticleTypes.LAVA, backX, this.getY() + 1.0D, backZ, 0.0D, 0.02D, 0.0D);
            }
            if (this.isTurretBroken() && this.tickCount % 4 == 0) {
                this.level().addParticle(ParticleTypes.CRIT, this.getX(), this.getY() + 1.55D, this.getZ(), 0.0D, 0.05D, 0.0D);
            }
        }

        LivingEntity driver = this.getControllingPassenger();
        if (driver != null) {
            // Keep passenger safe from fire, drowning, and fall damage inside the armored hull
            driver.clearFire();
            driver.setAirSupply(driver.getMaxAirSupply());
            driver.resetFallDistance();

            TankType type = this.getTankType();

            if (!this.isTurretBroken()) {
                if (this.level().isClientSide && driver instanceof Player p && p.isLocalPlayer()) {
                    if (!this.clientDriverAimInitialized) {
                        this.clientDriverTurretYaw = this.getTurretYaw();
                        this.clientDriverBarrelPitch = this.getBarrelPitch();
                        this.clientDriverAimInitialized = true;
                    }
                    // Target cursor yaw directly from driver.getYRot() (never delayed yHeadRot)
                    float targetYaw = driver.getYRot();
                    float diffYaw = Mth.wrapDegrees(targetYaw - this.clientDriverTurretYaw);
                    float stepYaw = Mth.clamp(diffYaw, -type.turretTurnSpeed, type.turretTurnSpeed);
                    this.clientDriverTurretYaw = Mth.wrapDegrees(this.clientDriverTurretYaw + stepYaw);

                    float targetPitch = Mth.clamp(driver.getXRot(), type.minBarrelPitch, type.maxBarrelPitch);
                    this.clientDriverBarrelPitch = Mth.lerp(0.45F, this.clientDriverBarrelPitch, targetPitch);

                    this.setTurretYaw(this.clientDriverTurretYaw);
                    this.setBarrelPitch(this.clientDriverBarrelPitch);

                    ModMessages.INSTANCE.sendToServer(new TankAimInputPacket(this.clientDriverTurretYaw, this.clientDriverBarrelPitch));
                } else if (!this.level().isClientSide && !(driver instanceof Player)) {
                    float targetYaw = driver.getYRot();
                    float diffYaw = Mth.wrapDegrees(targetYaw - this.getTurretYaw());
                    float stepYaw = Mth.clamp(diffYaw, -type.turretTurnSpeed, type.turretTurnSpeed);
                    this.setTurretYaw(Mth.wrapDegrees(this.getTurretYaw() + stepYaw));
                }
            }

            if (this.getFuel() > 0 && !this.isEngineBroken()) {
                if (this.level().isClientSide && this.tickCount % 3 == 0) {
                    double rad = Math.toRadians(this.getYRot());
                    double backX = this.getX() + Math.sin(rad) * 1.9D - Math.cos(rad) * 1.1D;
                    double backZ = this.getZ() - Math.cos(rad) * 1.9D - Math.sin(rad) * 1.1D;
                    this.level().addParticle(ParticleTypes.CAMPFIRE_COSY_SMOKE,
                            backX, this.getY() + 0.95D, backZ,
                            Math.sin(rad) * 0.04D, 0.03D, -Math.cos(rad) * 0.04D);
                }

                if (!this.level().isClientSide && this.tickCount % 25 == 0) {
                    float pitchSound = type == TankType.ABRAMS ? 0.95F : 0.55F;
                    this.level().playSound(null, this.blockPosition(), SoundEvents.MINECART_RIDING, SoundSource.NEUTRAL, 0.8F, pitchSound);
                }
            }
        } else if (!this.level().isClientSide && this.isEnemyAI()) {
            this.tickEnemyAI();
        }

        double speedSq = this.getDeltaMovement().horizontalDistanceSqr();
        if (speedSq > 0.0004D) {
            this.wheelRotation += (float) Math.sqrt(speedSq) * 1.8F;
            if (!this.level().isClientSide) {
                this.crushFoliageAndObstacles();

                if (speedSq > 0.02D) {
                    AABB ramBox = this.getBoundingBox().inflate(0.95D, 0.2D, 0.95D);
                    List<Entity> hitEntities = this.level().getEntities(this, ramBox,
                            e -> e instanceof LivingEntity && !(e instanceof T72TankEntity) && !this.isPassengerOfSameVehicle(e));
                    for (Entity victim : hitEntities) {
                        victim.hurt(this.damageSources().mobAttack(this), 12.0F);
                        Vec3 knock = this.getDeltaMovement().normalize().scale(1.25D);
                        victim.push(knock.x, 0.35D, knock.z);
                    }
                }
            }
        } else if (!this.level().isClientSide && (this.isVehicle() || this.isEnemyAI()) && this.tickCount % 5 == 0) {
            this.crushFoliageAndObstacles();
        }
    }

    private void updateSubPartPositions() {
        double rad = Math.toRadians(this.getYRot());
        double fx = -Math.sin(rad);
        double fz = Math.cos(rad);
        double rx = -Math.cos(rad);
        double rz = -Math.sin(rad);

        double x = this.getX();
        double y = this.getY();
        double z = this.getZ();

        // Outer lower step hitboxes (0.85 blocks high) around the central hull
        this.leftTrackPart.movePartTo(x - rx * 1.15D, y, z - rz * 1.15D);
        this.rightTrackPart.movePartTo(x + rx * 1.15D, y, z + rz * 1.15D);
        this.frontHullPart.movePartTo(x + fx * 1.45D, y, z + fz * 1.45D);
        this.rearHullPart.movePartTo(x - fx * 1.45D, y, z - fz * 1.45D);
        this.turretPart.movePartTo(x, y + 1.35D, z);
    }

    private void assistNearbyClimbingPlayers() {
        AABB climbArea = this.getBoundingBox().inflate(1.45D, 0.6D, 1.45D);
        List<Player> players = this.level().getEntitiesOfClass(Player.class, climbArea,
                p -> p.isAlive() && !p.isPassenger());
        for (Player p : players) {
            double relY = p.getY() - this.getY();
            double dist = Math.hypot(p.getX() - this.getX(), p.getZ() - this.getZ());
            // When player jumps near tracks/front/rear, help them step cleanly onto the 0.85m step and 1.40m hull deck
            if (dist <= 2.65D && relY >= -0.15D && relY <= 1.38D) {
                Vec3 dm = p.getDeltaMovement();
                if (dm.y > 0.04D || p.horizontalCollision) {
                    double targetStepY = relY < 0.78D ? (this.getY() + 0.86D) : (this.getY() + 1.42D);
                    if (targetStepY - p.getY() <= 0.95D && dm.y > -0.08D) {
                        p.setDeltaMovement(dm.x, Math.max(dm.y, 0.28D), dm.z);
                        p.fallDistance = 0.0F;
                    }
                }
            }
        }
    }

    private void crushFoliageAndObstacles() {
        AABB crushBox = this.getBoundingBox().inflate(1.05D, 0.35D, 1.05D);
        int minX = Mth.floor(crushBox.minX);
        int maxX = Mth.floor(crushBox.maxX);
        int minY = Mth.floor(this.getY() - 0.6D);
        int maxY = Mth.floor(crushBox.maxY + 0.45D);
        int minZ = Mth.floor(crushBox.minZ);
        int maxZ = Mth.floor(crushBox.maxZ);

        BlockPos.MutableBlockPos mpos = new BlockPos.MutableBlockPos();
        for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) {
                for (int y = minY; y <= maxY; y++) {
                    mpos.set(x, y, z);
                    BlockState state = this.level().getBlockState(mpos);
                    if (state.isAir()) continue;
                    Block block = state.getBlock();

                    // Trample farmland into dirt under the tracks
                    if (y <= Mth.floor(this.getY() + 0.2D) && (state.is(Blocks.FARMLAND) || block instanceof FarmBlock)) {
                        BlockPos abovePos = mpos.above();
                        BlockState aboveState = this.level().getBlockState(abovePos);
                        if (!aboveState.isAir() && isCrushablePlantOrObstacle(aboveState, aboveState.getBlock())) {
                            this.level().destroyBlock(abovePos, true, this);
                        }
                        this.level().setBlockAndUpdate(mpos, Blocks.DIRT.defaultBlockState());
                        continue;
                    }

                    if (y >= Mth.floor(this.getY()) && isCrushablePlantOrObstacle(state, block)) {
                        this.level().destroyBlock(mpos, true, this);
                    }
                }
            }
        }
    }

    private static boolean isCrushablePlantOrObstacle(BlockState state, Block block) {
        if (state.is(BlockTags.LEAVES)
                || state.is(BlockTags.CROPS)
                || state.is(BlockTags.FLOWERS)
                || state.is(BlockTags.TALL_FLOWERS)
                || state.is(BlockTags.SAPLINGS)
                || state.is(BlockTags.REPLACEABLE_BY_TREES)) {
            return true;
        }
        return block instanceof BushBlock
                || block instanceof LeavesBlock
                || block instanceof CropBlock
                || block instanceof StemBlock
                || block instanceof AttachedStemBlock
                || block instanceof SugarCaneBlock
                || block instanceof BambooStalkBlock
                || block instanceof BambooSaplingBlock
                || block instanceof VineBlock
                || block instanceof WebBlock
                || block instanceof CactusBlock
                || block instanceof SweetBerryBushBlock
                || block instanceof SnowLayerBlock
                || block instanceof MelonBlock
                || block instanceof PumpkinBlock
                || block instanceof CarvedPumpkinBlock
                || block instanceof TallGrassBlock
                || block instanceof DoublePlantBlock
                || block instanceof DeadBushBlock
                || block instanceof FlowerBlock
                || block instanceof FenceBlock
                || block instanceof FenceGateBlock;
    }

    private void tickSupplyAutoLoad() {
        // 1. Auto-refill Coaxial MG Ammo from Slots 4..5
        if (this.getMgAmmo() <= MAX_MG_AMMO - 250) {
            for (int i = 4; i <= 5; i++) {
                ItemStack s = this.tankInventory.getItem(i);
                if (s.is(T72Mod.MG_AMMO_BOX.get())) {
                    s.shrink(1);
                    this.setMgAmmo(Math.min(MAX_MG_AMMO, this.getMgAmmo() + 250));
                    this.level().playSound(null, this.blockPosition(), SoundEvents.ARMOR_EQUIP_IRON, SoundSource.PLAYERS, 0.8F, 1.2F);
                    break;
                } else if (s.is(Items.IRON_NUGGET) && s.getCount() >= 8) {
                    s.shrink(8);
                    this.setMgAmmo(Math.min(MAX_MG_AMMO, this.getMgAmmo() + 40));
                    break;
                }
            }
        }

        // 2. Auto-refill Fuel from Slots 6..7
        if (this.getFuel() <= MAX_FUEL - 60) {
            for (int i = 6; i <= 7; i++) {
                ItemStack s = this.tankInventory.getItem(i);
                int fuelVal = getFuelValue(s);
                if (fuelVal > 0 && this.getFuel() + fuelVal <= MAX_FUEL + 200) {
                    if (s.is(Items.LAVA_BUCKET)) {
                        this.tankInventory.setItem(i, new ItemStack(Items.BUCKET));
                    } else {
                        s.shrink(1);
                    }
                    this.setFuel(Math.min(MAX_FUEL, this.getFuel() + fuelVal));
                    this.level().playSound(null, this.blockPosition(), SoundEvents.BUCKET_FILL, SoundSource.PLAYERS, 0.7F, 1.1F);
                    break;
                }
            }
        }

        // 3. Sync total main cannon shells count in Slots 0..3
        if (this.tickCount % 5 == 0) {
            this.updateShellCountData();
        }
    }

    public void updateShellCountData() {
        int total = 0;
        for (int i = 0; i < 4; i++) {
            ItemStack s = this.tankInventory.getItem(i);
            if (isMainShellItem(s)) {
                total += s.getCount();
            }
        }
        this.entityData.set(DATA_SHELL_COUNT, total);
    }

    private void tickEnemyAI() {
        // Find nearest target: another tank with a player driver, a player, or a Warden/Monster
        LivingEntity target = null;
        double bestDistSq = 48.0D * 48.0D;

        List<T72TankEntity> tanks = this.level().getEntitiesOfClass(T72TankEntity.class, this.getBoundingBox().inflate(48.0D),
                t -> t != this && t.isAlive() && (t.getControllingPassenger() instanceof Player || !t.isEnemyAI()));
        for (T72TankEntity t : tanks) {
            double d = this.distanceToSqr(t);
            if (d < bestDistSq) {
                bestDistSq = d;
                target = t;
            }
        }

        if (target == null) {
            List<Player> players = this.level().getEntitiesOfClass(Player.class, this.getBoundingBox().inflate(42.0D),
                    p -> p.isAlive() && !p.isCreative() && !p.isSpectator());
            for (Player p : players) {
                double d = this.distanceToSqr(p);
                if (d < bestDistSq) {
                    bestDistSq = d;
                    target = p;
                }
            }
        }

        if (target == null) {
            List<Warden> wardens = this.level().getEntitiesOfClass(Warden.class, this.getBoundingBox().inflate(42.0D), LivingEntity::isAlive);
            if (!wardens.isEmpty()) target = wardens.get(0);
        }

        if (target == null) return;

        double dx = target.getX() - this.getX();
        double dy = (target.getY() + target.getBbHeight() * 0.5D) - (this.getY() + 1.4D);
        double dz = target.getZ() - this.getZ();
        double horizDist = Math.hypot(dx, dz);

        float desiredYaw = (float) (Mth.atan2(-dx, dz) * (180.0D / Math.PI));
        float desiredPitch = (float) (-Mth.atan2(dy, horizDist) * (180.0D / Math.PI));

        TankType type = this.getTankType();

        // Rotate turret if not broken
        if (!this.isTurretBroken()) {
            float diffYaw = Mth.wrapDegrees(desiredYaw - this.getTurretYaw());
            float step = Mth.clamp(diffYaw, -type.turretTurnSpeed * 0.65F, type.turretTurnSpeed * 0.65F);
            this.setTurretYaw(Mth.wrapDegrees(this.getTurretYaw() + step));
            this.setBarrelPitch(Mth.clamp(desiredPitch, type.minBarrelPitch, type.maxBarrelPitch));
        }

        // Maneuver hull if tracks & fuel are available
        if (!this.isTracksBroken() && this.getFuel() > 0) {
            float hullDiff = Mth.wrapDegrees(desiredYaw - this.getYRot());
            this.setYRot(this.getYRot() + Mth.clamp(hullDiff, -type.hullTurnSpeed * 0.7F, type.hullTurnSpeed * 0.7F));
            if (horizDist > 16.0D) {
                double rad = Math.toRadians(this.getYRot());
                float moveSpd = this.isEngineBroken() ? 0.04F : type.driveSpeed * 0.45F;
                this.setDeltaMovement(this.getDeltaMovement().add(-Math.sin(rad) * moveSpd * 0.2D, 0.0D, Math.cos(rad) * moveSpd * 0.2D));
            }
        }

        // Fire main cannon if aimed within 8 degrees
        if (Math.abs(Mth.wrapDegrees(desiredYaw - this.getTurretYaw())) < 8.0F && this.getReloadTicks() == 0) {
            this.fireMainCannon(null);
        }
    }

    @Override
    public void travel(Vec3 travelVector) {
        if (this.isAlive() && this.isVehicle() && this.getControllingPassenger() instanceof Player player) {
            TankType type = this.getTankType();

            boolean hasInput = Math.abs(player.xxa) > 0.01F || Math.abs(player.zza) > 0.01F;

            // Check broken tracks
            if (this.isTracksBroken()) {
                if (hasInput && !this.level().isClientSide && this.tickCount % 20 == 0) {
                    player.displayClientMessage(Component.literal("⚠ Гусеница сбита! Танк обездвижен (нажмите R для ремонта ЗИП).")
                            .withStyle(ChatFormatting.RED), true);
                }
                super.travel(new Vec3(0.0D, travelVector.y, 0.0D));
                return;
            }

            // Check fuel
            if (this.getFuel() <= 0 && !player.getAbilities().instabuild) {
                if (hasInput && !this.level().isClientSide && this.tickCount % 20 == 0) {
                    player.displayClientMessage(Component.literal("⛽ Топливный бак пуст! Загрузите канистру или уголь в инвентарь танка (клавиша I).")
                            .withStyle(ChatFormatting.GOLD), true);
                }
                super.travel(new Vec3(0.0D, travelVector.y, 0.0D));
                return;
            }

            float enginePenalty = this.isEngineBroken() ? 0.22F : 1.0F;

            float turnInput = -player.xxa;
            this.setYRot(this.getYRot() + turnInput * type.hullTurnSpeed * enginePenalty);
            this.yBodyRot = this.getYRot();
            this.yHeadRot = this.getYRot();

            float forwardInput = player.zza;
            if (forwardInput < 0.0F) {
                forwardInput *= type.reverseFactor;
            }

            // Consume fuel on server while driving
            if (!this.level().isClientSide && hasInput && !player.getAbilities().instabuild) {
                this.fuelBurnTicker++;
                int ticksPerFuelUnit = Math.max(4, Math.round(14.0F / type.fuelConsumptionMult));
                if (this.isEngineBroken()) ticksPerFuelUnit = Math.max(2, ticksPerFuelUnit / 2);
                if (this.fuelBurnTicker >= ticksPerFuelUnit) {
                    this.fuelBurnTicker = 0;
                    this.setFuel(Math.max(0, this.getFuel() - 1));
                }
            }

            this.setSpeed(type.driveSpeed * enginePenalty);
            super.travel(new Vec3(0.0D, travelVector.y, forwardInput));
            return;
        }
        super.travel(travelVector);
    }

    public void fireMainCannon(@Nullable Player shooter) {
        if (this.level().isClientSide || this.getReloadTicks() > 0) return;

        TankType type = this.getTankType();

        if (shooter != null && !shooter.getAbilities().instabuild) {
            ItemStack foundAmmo = ItemStack.EMPTY;
            // 1. Check Tank Inventory Slots 0..3 first
            for (int i = 0; i < 4; i++) {
                ItemStack s = this.tankInventory.getItem(i);
                if (isMainShellItem(s)) {
                    foundAmmo = s;
                    break;
                }
            }
            // 2. Fallback to shooter's inventory
            if (foundAmmo.isEmpty()) {
                for (int i = 0; i < shooter.getInventory().getContainerSize(); i++) {
                    ItemStack s = shooter.getInventory().getItem(i);
                    if (isMainShellItem(s)) {
                        foundAmmo = s;
                        break;
                    }
                }
            }
            if (foundAmmo.isEmpty()) {
                shooter.displayClientMessage(Component.literal("Боеукладка пуста! Загрузите 125-мм или 120-мм выстрелы в слоты танка (клавиша I).")
                        .withStyle(ChatFormatting.RED), true);
                this.level().playSound(null, this.blockPosition(), SoundEvents.DISPENSER_FAIL, SoundSource.PLAYERS, 1.0F, 0.8F);
                return;
            }
            foundAmmo.shrink(1);
            this.updateShellCountData();
        }

        float yawRad = (float) Math.toRadians(this.getTurretYaw());
        float pitchRad = (float) Math.toRadians(this.getBarrelPitch());

        Vec3 barrelDir = new Vec3(
                -Mth.sin(yawRad) * Mth.cos(pitchRad),
                -Mth.sin(pitchRad),
                Mth.cos(yawRad) * Mth.cos(pitchRad)
        ).normalize();

        Vec3 muzzlePos = new Vec3(this.getX(), this.getY() + 1.42D, this.getZ()).add(barrelDir.scale(3.9D));

        TankShellEntity shell = new TankShellEntity(T72Mod.TANK_SHELL.get(), this.level());
        if (shooter != null) {
            shell.setOwner(shooter);
        } else {
            shell.setOwner(this);
        }
        shell.configureShell(this.getId(), type.shellDirectDamage, type.shellExplosionRadius, type.shellGravity);
        shell.setPos(muzzlePos.x, muzzlePos.y, muzzlePos.z);
        shell.shoot(barrelDir.x, barrelDir.y, barrelDir.z, type.shellSpeed, 0.10F);
        this.level().addFreshEntity(shell);

        if (this.level() instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(ParticleTypes.FLASH, muzzlePos.x, muzzlePos.y, muzzlePos.z, 2, 0, 0, 0, 0);
            serverLevel.sendParticles(ParticleTypes.EXPLOSION, muzzlePos.x, muzzlePos.y, muzzlePos.z, 4, 0.2, 0.2, 0.2, 0.05);
            serverLevel.sendParticles(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, muzzlePos.x, muzzlePos.y, muzzlePos.z, 18, 0.35, 0.35, 0.35, 0.04);
        }

        this.level().playSound(null, this.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 3.0F, 0.65F);
        this.level().playSound(null, this.blockPosition(), SoundEvents.FIREWORK_ROCKET_BLAST, SoundSource.PLAYERS, 2.5F, 0.5F);

        this.push(-barrelDir.x * 0.32D, 0.04D, -barrelDir.z * 0.32D);

        this.setRecoilTicks(10);
        int reload = this.isTurretBroken() ? (int) (type.reloadTicks * 1.5F) : type.reloadTicks;
        this.setReloadTicks(reload);
    }

    public void fireCoaxialMG(Player shooter) {
        if (this.level().isClientSide) return;

        // Check MG ammo limit
        if (!shooter.getAbilities().instabuild) {
            if (this.getMgAmmo() <= 0) {
                this.tickSupplyAutoLoad();
            }
            if (this.getMgAmmo() <= 0) {
                if (this.tickCount % 9 == 0) {
                    shooter.displayClientMessage(Component.literal("Пулемётная лента пуста! Положите короб 7.62мм в слот пулемёта (клавиша I).")
                            .withStyle(ChatFormatting.RED), true);
                    this.level().playSound(null, this.blockPosition(), SoundEvents.DISPENSER_FAIL, SoundSource.PLAYERS, 0.9F, 1.2F);
                }
                return;
            }
            this.setMgAmmo(this.getMgAmmo() - 1);
        }

        float yawRad = (float) Math.toRadians(this.getTurretYaw());
        float pitchRad = (float) Math.toRadians(this.getBarrelPitch());
        Vec3 dir = new Vec3(
                -Mth.sin(yawRad) * Mth.cos(pitchRad),
                -Mth.sin(pitchRad),
                Mth.cos(yawRad) * Mth.cos(pitchRad)
        ).normalize();

        Vec3 start = new Vec3(this.getX(), this.getY() + 1.38D, this.getZ()).add(dir.scale(2.1D));
        Vec3 end = start.add(dir.scale(48.0D));

        if (this.level() instanceof ServerLevel serverLevel) {
            for (int i = 2; i < 40; i += 4) {
                Vec3 p = start.add(dir.scale(i));
                serverLevel.sendParticles(ParticleTypes.CRIT, p.x, p.y, p.z, 1, 0, 0, 0, 0);
            }
        }

        // Also break leaves/glass along MG line of fire
        for (int d = 2; d <= 20; d += 2) {
            BlockPos bp = BlockPos.containing(start.add(dir.scale(d)));
            BlockState bs = this.level().getBlockState(bp);
            if (bs.is(BlockTags.LEAVES) || bs.getBlock() instanceof StainedGlassPaneBlock || bs.is(Blocks.GLASS_PANE)) {
                this.level().destroyBlock(bp, true, this);
            }
        }

        AABB rayBox = new AABB(start, end).inflate(1.0D);
        List<LivingEntity> targets = this.level().getEntitiesOfClass(LivingEntity.class, rayBox,
                e -> e != this && !(e instanceof T72TankEntity) && e != shooter && e.getBoundingBox().inflate(0.35D).clip(start, end).isPresent());

        for (LivingEntity target : targets) {
            target.invulnerableTime = 0;
            target.hurt(this.damageSources().mobProjectile(this, shooter), 6.5F);
        }

        this.level().playSound(null, this.blockPosition(), SoundEvents.FIREWORK_ROCKET_LAUNCH, SoundSource.PLAYERS, 1.2F, 1.8F);
    }

    public void deploySmokeScreen() {
        if (this.level().isClientSide || this.getSmokeCooldown() > 0) return;

        float yawRad = (float) Math.toRadians(this.getTurretYaw());
        Vec3 forward = new Vec3(-Mth.sin(yawRad), 0.2D, Mth.cos(yawRad)).normalize();
        Vec3 smokeCenter = this.position().add(forward.scale(8.5D));

        if (this.level() instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE,
                    smokeCenter.x, smokeCenter.y + 1.5D, smokeCenter.z,
                    120, 3.8D, 2.0D, 3.8D, 0.01D);
            serverLevel.sendParticles(ParticleTypes.LARGE_SMOKE,
                    smokeCenter.x, smokeCenter.y + 1.0D, smokeCenter.z,
                    60, 3.0D, 1.5D, 3.0D, 0.02D);
        }

        List<Monster> monsters = this.level().getEntitiesOfClass(Monster.class, this.getBoundingBox().inflate(24.0D));
        for (Monster m : monsters) {
            m.setTarget(null);
        }

        this.level().playSound(null, this.blockPosition(), SoundEvents.DISPENSER_LAUNCH, SoundSource.PLAYERS, 2.0F, 0.7F);
        this.setSmokeCooldown(300);
    }

    public int resolveModuleAtPosition(@Nullable Vec3 hitPos) {
        if (hitPos == null) return TankPartEntity.MODULE_HULL_FRONT;
        double relY = hitPos.y - this.getY();
        if (relY >= 1.25D) {
            return TankPartEntity.MODULE_TURRET;
        }

        double rad = Math.toRadians(this.getYRot());
        double fx = -Math.sin(rad);
        double fz = Math.cos(rad);
        double dx = hitPos.x - this.getX();
        double dz = hitPos.z - this.getZ();
        double forwardProj = dx * fx + dz * fz;

        if (forwardProj < -0.85D) {
            return TankPartEntity.MODULE_ENGINE;
        } else if (forwardProj > 0.95D && relY >= 0.75D) {
            return TankPartEntity.MODULE_HULL_FRONT;
        }
        return TankPartEntity.MODULE_TRACKS;
    }

    public void onDirectShellHit(int moduleType, Vec3 hitPos, TankShellEntity shell, float rawShellDamage) {
        if (this.level().isClientSide || !this.isAlive()) return;
        DamageSource src = this.damageSources().thrown(shell, shell.getOwner());
        this.applyModularTankDamage(moduleType, src, rawShellDamage, true);
    }

    public boolean hurtFromPart(TankPartEntity part, DamageSource source, float amount) {
        if (this.level().isClientSide || !this.isAlive()) return false;
        return this.applyModularTankDamage(part.moduleType, source, amount, false);
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (this.level().isClientSide || !this.isAlive()) return false;
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return super.hurt(source, amount);
        }
        int module = this.resolveModuleAtPosition(source.getSourcePosition());
        return this.applyModularTankDamage(module, source, amount, false);
    }

    private boolean applyModularTankDamage(int moduleType, DamageSource source, float amount, boolean isDirectTankShell) {
        // Ignore self-damage from own cannon muzzle blast
        if (source.getDirectEntity() instanceof TankShellEntity shell && shell.getOwner() != null
                && this.isPassengerOfSameVehicle(shell.getOwner())) {
            return false;
        }

        // Complete immunity to small arms, arrows, fire, fall, drowning, cactus
        if (!isDirectTankShell && (source.getDirectEntity() instanceof AbstractArrow
                || source.is(DamageTypeTags.IS_FIRE)
                || source.is(DamageTypeTags.IS_FALL)
                || source.is(DamageTypeTags.IS_DROWNING)
                || source.is(DamageTypes.CACTUS)
                || source.is(DamageTypes.SWEET_BERRY_BUSH)
                || source.is(DamageTypes.IN_WALL))) {
            this.level().playSound(null, this.blockPosition(), SoundEvents.ANVIL_LAND, SoundSource.NEUTRAL, 0.5F, 1.8F);
            return false;
        }

        Entity attacker = source.getEntity();
        boolean isWarden = attacker instanceof Warden || source.is(DamageTypes.SONIC_BOOM);
        boolean isHeavyBossOrGolem = attacker instanceof WitherBoss
                || attacker instanceof EnderDragon
                || attacker instanceof Ravager
                || attacker instanceof IronGolem;
        boolean isExplosion = source.is(DamageTypeTags.IS_EXPLOSION);

        // Weak attacks from ordinary mobs bounce off tank armor
        if (!isDirectTankShell && !isWarden && !isHeavyBossOrGolem && !isExplosion && amount < 14.0F) {
            this.level().playSound(null, this.blockPosition(), SoundEvents.ANVIL_LAND, SoundSource.NEUTRAL, 0.5F, 1.75F);
            return false;
        }

        float effectiveHullDamage = amount;
        int moduleDamage = 0;

        if (isDirectTankShell) {
            effectiveHullDamage = amount;
            moduleDamage = 100; // A direct hit from a tank cannon knocks out the hit module!
        } else if (isWarden) {
            effectiveHullDamage = Math.max(amount * 2.2F, 65.0F);
            moduleDamage = 85;
            // Warden Sonic Boom or melee hits turret or tracks heavily
            if (source.is(DamageTypes.SONIC_BOOM)) {
                moduleType = TankPartEntity.MODULE_TURRET;
            }
        } else if (isExplosion) {
            // Avoid double-counting vanilla explosion after onDirectShellHit
            if (source.getDirectEntity() instanceof TankShellEntity) {
                return false;
            }
            effectiveHullDamage = amount * 0.85F;
            moduleDamage = (int) Math.min(100, amount * 1.8F);
        } else {
            effectiveHullDamage = amount * 0.55F;
            moduleDamage = (int) Math.min(75, amount * 1.4F);
        }

        // Frontal armor & Leopard 2A6 wedge turret armor reduction
        if (moduleType == TankPartEntity.MODULE_HULL_FRONT) {
            effectiveHullDamage *= 0.70F;
        } else if (moduleType == TankPartEntity.MODULE_TURRET && this.getTankType() == TankType.LEOPARD2) {
            effectiveHullDamage *= 0.78F;
        }

        // Apply module damage
        if (moduleDamage > 0) {
            this.damageSpecificModule(moduleType, moduleDamage);
        }

        this.invulnerableTime = 0;
        boolean hurtResult = super.hurt(source, effectiveHullDamage);
        this.level().playSound(null, this.blockPosition(), SoundEvents.IRON_GOLEM_HURT, SoundSource.NEUTRAL, 1.4F, 0.65F);
        return hurtResult;
    }

    private void damageSpecificModule(int moduleType, int dmg) {
        Player driver = this.getControllingPassenger() instanceof Player p ? p : null;

        if (moduleType == TankPartEntity.MODULE_TURRET) {
            int prev = this.getTurretHealth();
            int next = Math.max(0, prev - dmg);
            this.setTurretHealth(next);
            if (prev > 0 && next == 0) {
                this.level().playSound(null, this.blockPosition(), SoundEvents.ANVIL_BREAK, SoundSource.PLAYERS, 1.5F, 0.75F);
                if (driver != null) {
                    driver.displayClientMessage(Component.literal("💥 КРИТ БАШНИ: Привод наведения выбит! Башня заклинена (нажмите R для ремонта)!")
                            .withStyle(ChatFormatting.RED, ChatFormatting.BOLD), true);
                }
            }
        } else if (moduleType == TankPartEntity.MODULE_TRACKS) {
            int prev = this.getTracksHealth();
            int next = Math.max(0, prev - dmg);
            this.setTracksHealth(next);
            if (prev > 0 && next == 0) {
                this.level().playSound(null, this.blockPosition(), SoundEvents.ANVIL_BREAK, SoundSource.PLAYERS, 1.5F, 0.6F);
                if (driver != null) {
                    driver.displayClientMessage(Component.literal("💥 СБИТА ГУСЕНИЦА: Ходовая часть разрушена! Танк обездвижен (нажмите R для ремонта)!")
                            .withStyle(ChatFormatting.RED, ChatFormatting.BOLD), true);
                }
            }
        } else if (moduleType == TankPartEntity.MODULE_ENGINE) {
            int prev = this.getEngineHealth();
            int next = Math.max(0, prev - dmg);
            this.setEngineHealth(next);
            if (prev > 0 && next == 0) {
                this.level().playSound(null, this.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 1.2F, 0.9F);
                if (driver != null) {
                    driver.displayClientMessage(Component.literal("💥 ПОЖАР МТО: Двигатель пробит! Критическая потеря тяги (нажмите R для ремонта)!")
                            .withStyle(ChatFormatting.RED, ChatFormatting.BOLD), true);
                }
            }
        } else if (moduleType == TankPartEntity.MODULE_HULL_FRONT && dmg >= 85) {
            // Heavy hit to lower glacis can also damage tracks
            int prev = this.getTracksHealth();
            int next = Math.max(0, prev - dmg / 2);
            this.setTracksHealth(next);
        }
    }

    @Override
    public void die(DamageSource source) {
        if (!this.level().isClientSide) {
            // Eject passengers before explosion and drop tank inventory
            this.ejectPassengers();
            Containers.dropContents(this.level(), this.blockPosition(), this.tankInventory);
            if (this.level() instanceof ServerLevel serverLevel) {
                serverLevel.sendParticles(ParticleTypes.EXPLOSION_EMITTER, this.getX(), this.getY() + 1.0D, this.getZ(), 3, 0.5, 0.5, 0.5, 0.0);
                serverLevel.sendParticles(ParticleTypes.LARGE_SMOKE, this.getX(), this.getY() + 1.2D, this.getZ(), 45, 1.2, 0.8, 1.2, 0.05);
            }
            this.level().playSound(null, this.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.NEUTRAL, 3.0F, 0.6F);
        }
        super.die(source);
    }

    @Override
    public boolean removeWhenFarAway(double dist) {
        return false;
    }

    public TankType getTankType() {
        return TankType.byOrdinal(this.entityData.get(DATA_TANK_TYPE));
    }

    public void setTankType(TankType type) {
        this.entityData.set(DATA_TANK_TYPE, type.ordinal());
    }

    public float getTurretYaw() { return this.entityData.get(DATA_TURRET_YAW); }
    public void setTurretYaw(float yaw) { this.entityData.set(DATA_TURRET_YAW, yaw); }

    public float getBarrelPitch() { return this.entityData.get(DATA_BARREL_PITCH); }
    public void setBarrelPitch(float pitch) { this.entityData.set(DATA_BARREL_PITCH, pitch); }

    public boolean isHatchOpen() { return this.entityData.get(DATA_HATCH_OPEN); }
    public void setHatchOpen(boolean open) { this.entityData.set(DATA_HATCH_OPEN, open); }

    public int getReloadTicks() { return this.entityData.get(DATA_RELOAD_TICKS); }
    public void setReloadTicks(int ticks) { this.entityData.set(DATA_RELOAD_TICKS, ticks); }

    public int getRecoilTicks() { return this.entityData.get(DATA_RECOIL_TICKS); }
    public void setRecoilTicks(int ticks) { this.entityData.set(DATA_RECOIL_TICKS, ticks); }

    public int getSmokeCooldown() { return this.entityData.get(DATA_SMOKE_COOLDOWN); }
    public void setSmokeCooldown(int ticks) { this.entityData.set(DATA_SMOKE_COOLDOWN, ticks); }

    public int getFuel() { return this.entityData.get(DATA_FUEL); }
    public void setFuel(int fuel) { this.entityData.set(DATA_FUEL, Mth.clamp(fuel, 0, MAX_FUEL)); }

    public int getMgAmmo() { return this.entityData.get(DATA_MG_AMMO); }
    public void setMgAmmo(int ammo) { this.entityData.set(DATA_MG_AMMO, Mth.clamp(ammo, 0, MAX_MG_AMMO)); }

    public int getShellCount() { return this.entityData.get(DATA_SHELL_COUNT); }

    public int getTurretHealth() { return this.entityData.get(DATA_TURRET_HEALTH); }
    public void setTurretHealth(int hp) { this.entityData.set(DATA_TURRET_HEALTH, Mth.clamp(hp, 0, MAX_MODULE_HEALTH)); }
    public boolean isTurretBroken() { return this.getTurretHealth() <= 0; }

    public int getTracksHealth() { return this.entityData.get(DATA_TRACKS_HEALTH); }
    public void setTracksHealth(int hp) { this.entityData.set(DATA_TRACKS_HEALTH, Mth.clamp(hp, 0, MAX_MODULE_HEALTH)); }
    public boolean isTracksBroken() { return this.getTracksHealth() <= 0; }

    public int getEngineHealth() { return this.entityData.get(DATA_ENGINE_HEALTH); }
    public void setEngineHealth(int hp) { this.entityData.set(DATA_ENGINE_HEALTH, Mth.clamp(hp, 0, MAX_MODULE_HEALTH)); }
    public boolean isEngineBroken() { return this.getEngineHealth() <= 0; }

    public boolean isEnemyAI() { return this.entityData.get(DATA_ENEMY_AI); }
    public void setEnemyAI(boolean ai) { this.entityData.set(DATA_ENEMY_AI, ai); }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putFloat("TurretYaw", getTurretYaw());
        tag.putFloat("BarrelPitch", getBarrelPitch());
        tag.putBoolean("HatchOpen", isHatchOpen());
        tag.putInt("TankType", getTankType().ordinal());
        tag.putInt("Fuel", getFuel());
        tag.putInt("MgAmmo", getMgAmmo());
        tag.putInt("TurretHealth", getTurretHealth());
        tag.putInt("TracksHealth", getTracksHealth());
        tag.putInt("EngineHealth", getEngineHealth());
        tag.putBoolean("EnemyAI", isEnemyAI());
        tag.putBoolean("StarterLoaded", this.starterLoadoutInitialized);

        ListTag itemsTag = new ListTag();
        for (int i = 0; i < this.tankInventory.getContainerSize(); i++) {
            ItemStack stack = this.tankInventory.getItem(i);
            if (!stack.isEmpty()) {
                CompoundTag slotTag = new CompoundTag();
                slotTag.putByte("Slot", (byte) i);
                stack.save(slotTag);
                itemsTag.add(slotTag);
            }
        }
        tag.put("TankItems", itemsTag);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("TurretYaw")) setTurretYaw(tag.getFloat("TurretYaw"));
        if (tag.contains("BarrelPitch")) setBarrelPitch(tag.getFloat("BarrelPitch"));
        if (tag.contains("HatchOpen")) setHatchOpen(tag.getBoolean("HatchOpen"));
        if (tag.contains("TankType")) setTankType(TankType.byOrdinal(tag.getInt("TankType")));
        if (tag.contains("Fuel")) setFuel(tag.getInt("Fuel"));
        if (tag.contains("MgAmmo")) setMgAmmo(tag.getInt("MgAmmo"));
        if (tag.contains("TurretHealth")) setTurretHealth(tag.getInt("TurretHealth"));
        if (tag.contains("TracksHealth")) setTracksHealth(tag.getInt("TracksHealth"));
        if (tag.contains("EngineHealth")) setEngineHealth(tag.getInt("EngineHealth"));
        if (tag.contains("EnemyAI")) setEnemyAI(tag.getBoolean("EnemyAI"));
        if (tag.contains("StarterLoaded")) this.starterLoadoutInitialized = tag.getBoolean("StarterLoaded");

        if (tag.contains("TankItems", Tag.TAG_LIST)) {
            this.tankInventory.clearContent();
            ListTag itemsTag = tag.getList("TankItems", Tag.TAG_COMPOUND);
            for (int i = 0; i < itemsTag.size(); i++) {
                CompoundTag slotTag = itemsTag.getCompound(i);
                int slot = slotTag.getByte("Slot") & 255;
                if (slot < this.tankInventory.getContainerSize()) {
                    this.tankInventory.setItem(slot, ItemStack.of(slotTag));
                }
            }
            this.updateShellCountData();
        }
    }
}
