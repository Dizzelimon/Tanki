package com.example.t72mod.inventory;

import com.example.t72mod.T72Mod;
import com.example.t72mod.entity.T72TankEntity;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public class TankInventoryMenu extends AbstractContainerMenu {
    public static final int TANK_SLOT_COUNT = 9;
    private final Container tankContainer;
    private final T72TankEntity tank;

    // Client constructor
    public TankInventoryMenu(int containerId, Inventory playerInv, FriendlyByteBuf extraData) {
        this(containerId, playerInv, getTankFromBuf(playerInv, extraData));
    }

    private static T72TankEntity getTankFromBuf(Inventory playerInv, FriendlyByteBuf buf) {
        int entityId = buf.readInt();
        Entity entity = playerInv.player.level().getEntity(entityId);
        return entity instanceof T72TankEntity t ? t : null;
    }

    public TankInventoryMenu(int containerId, Inventory playerInv, T72TankEntity tank) {
        this(containerId, playerInv, tank != null ? tank.getTankInventory() : new SimpleContainer(TANK_SLOT_COUNT), tank);
    }

    public TankInventoryMenu(int containerId, Inventory playerInv, Container tankContainer, T72TankEntity tank) {
        super(T72Mod.TANK_MENU.get(), containerId);
        checkContainerSize(tankContainer, TANK_SLOT_COUNT);
        this.tankContainer = tankContainer;
        this.tank = tank;
        tankContainer.startOpen(playerInv.player);

        // Slots 0..3: Main Cannon Ammo (125mm / 120mm shells)
        for (int i = 0; i < 4; i++) {
            this.addSlot(new Slot(tankContainer, i, 8 + i * 18, 26) {
                @Override
                public boolean mayPlace(ItemStack stack) {
                    return T72TankEntity.isMainShellItem(stack);
                }
            });
        }

        // Slots 4..5: Coaxial Machine Gun Ammo Boxes (7.62mm)
        for (int i = 0; i < 2; i++) {
            this.addSlot(new Slot(tankContainer, 4 + i, 88 + i * 18, 26) {
                @Override
                public boolean mayPlace(ItemStack stack) {
                    return stack.is(T72Mod.MG_AMMO_BOX.get()) || stack.is(Items.IRON_NUGGET) || stack.is(Items.ARROW);
                }
            });
        }

        // Slots 6..7: Fuel Canisters / Coal
        for (int i = 0; i < 2; i++) {
            this.addSlot(new Slot(tankContainer, 6 + i, 8 + i * 18, 58) {
                @Override
                public boolean mayPlace(ItemStack stack) {
                    return T72TankEntity.getFuelValue(stack) > 0;
                }
            });
        }

        // Slot 8: Repair Kit / Iron Ingot / Iron Block
        this.addSlot(new Slot(tankContainer, 8, 88, 58) {
            @Override
            public boolean mayPlace(ItemStack stack) {
                return T72TankEntity.isRepairItem(stack);
            }
        });

        // Player Inventory (3 rows of 9)
        int playerInvY = 92;
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.addSlot(new Slot(playerInv, col + row * 9 + 9, 8 + col * 18, playerInvY + row * 18));
            }
        }

        // Player Hotbar
        int hotbarY = playerInvY + 58;
        for (int col = 0; col < 9; col++) {
            this.addSlot(new Slot(playerInv, col, 8 + col * 18, hotbarY));
        }
    }

    public T72TankEntity getTank() {
        return this.tank;
    }

    @Override
    public boolean stillValid(Player player) {
        if (this.tank == null || !this.tank.isAlive()) return false;
        return player.distanceTo(this.tank) <= 8.0F;
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack result = ItemStack.EMPTY;
        Slot slot = this.slots.get(index);
        if (slot != null && slot.hasItem()) {
            ItemStack stackInSlot = slot.getItem();
            result = stackInSlot.copy();

            if (index < TANK_SLOT_COUNT) {
                if (!this.moveItemStackTo(stackInSlot, TANK_SLOT_COUNT, this.slots.size(), true)) {
                    return ItemStack.EMPTY;
                }
            } else {
                if (T72TankEntity.isMainShellItem(stackInSlot)) {
                    if (!this.moveItemStackTo(stackInSlot, 0, 4, false)) return ItemStack.EMPTY;
                } else if (stackInSlot.is(T72Mod.MG_AMMO_BOX.get()) || stackInSlot.is(Items.IRON_NUGGET)) {
                    if (!this.moveItemStackTo(stackInSlot, 4, 6, false)) return ItemStack.EMPTY;
                } else if (T72TankEntity.getFuelValue(stackInSlot) > 0) {
                    if (!this.moveItemStackTo(stackInSlot, 6, 8, false)) return ItemStack.EMPTY;
                } else if (T72TankEntity.isRepairItem(stackInSlot)) {
                    if (!this.moveItemStackTo(stackInSlot, 8, 9, false)) return ItemStack.EMPTY;
                } else {
                    return ItemStack.EMPTY;
                }
            }

            if (stackInSlot.isEmpty()) {
                slot.setByPlayer(ItemStack.EMPTY);
            } else {
                slot.setChanged();
            }
        }
        return result;
    }

    @Override
    public void removed(Player player) {
        super.removed(player);
        this.tankContainer.stopOpen(player);
    }
}
