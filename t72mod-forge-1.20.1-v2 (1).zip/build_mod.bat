@echo off
chcp 65001 >nul
echo ========================================================
echo Сборка мода T-72B (Minecraft Forge 1.20.1)...
echo ========================================================
if exist gradlew.bat (
    call gradlew.bat build
) else (
    gradle build
)
echo.
echo Готовый .jar файл находится в папке build\libs\
pause
